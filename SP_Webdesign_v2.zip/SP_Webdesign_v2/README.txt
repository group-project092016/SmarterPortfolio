Smarter Portfolio Website V2

Changes:

Home.htm:
-Updated vertical spacing between tool icons when viewed on a smaller screen.
-Linked every html page.
-Set footer to the bottom of the page regardless of screen size.(Alan helped me out with this)

PortfolioBuilder.htm, CreditCardWizard.htm, ExpectedGrowthCalculator.htm:
-Made the form width narrower.
-Wrote script to retrieve form input. The script prints the input in a Modal(dialog box).
-Linked every html page.
-Set footer to the bottom of the page regardless of screen size.

Newly Created Pages:
-AboutUs.htm
-FAQ.htm
-Support.htm
-Language.htm
-Privacy.htm
