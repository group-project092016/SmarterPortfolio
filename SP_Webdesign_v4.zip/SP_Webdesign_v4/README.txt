Smarter Portfolio Website V4

Changes:

-Added animation onto the Home.htm page and AboutUs.htm page.
