Smarter Portfolio Website V6

Changes:

-Changed AboutUs background and added header background.
-Added Leon’s form into the Credit Card wizard template.
-Added Header backgrounds on Portfolio Builder, Expected Growth Calculator, and Credit Card Wizard pages.
-Added an investment goal tab in the Portfolio Builder page. This hides and shows buttons that will trigger its modal.
-Cleared the FAQ page background. Reformatted the appearance of the questions.