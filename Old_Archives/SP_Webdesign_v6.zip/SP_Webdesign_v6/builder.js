
  var age = 0;
  var moneyAmount = 0;
  var goalText = "";
  var preferenceText = "";
  var internationalText = "";

  //get value of age and money
  function getTextBoxInput(){

    age = document.getElementById("number-age").value;
    moneyAmount = document.getElementById("number-capital").value;
  }

  //get user input from select boxes

  function getGoal(element){

    goalText = element.options[element.selectedIndex].text;
  }

  function getPreference(element){

    preferenceText = element.options[element.selectedIndex].text;
  }

  //get checkbox input
  function getInternational(){

    if(document.getElementById("checkbox-1474621289446").checked){
      internationalText = document.getElementById("checkbox-1474621289446").value;
    }

    else if(document.getElementById("checkbox-1474621289447").checked){
      internationalText = document.getElementById("checkbox-1474621289447").value;
    }
  }

  function printResult(){

    //print user input
    document.getElementById("sampleResultAge").innerHTML = age;
    document.getElementById("sampleResultMoneyAmount").innerHTML = moneyAmount;
    document.getElementById("sampleResultGoal").innerHTML = goalText;
    document.getElementById("sampleResultPreference").innerHTML = preferenceText;
    document.getElementById("sampleResultInternational").innerHTML = internationalText

    //clear user input
    document.getElementById("number-age").value = "";
    document.getElementById("number-capital").value = "";
    document.getElementById("select-goal").value = "";
    document.getElementById("select-1474621416872").value = "";
    document.getElementById("checkbox-1474621289446").checked = false;
    document.getElementById("checkbox-1474621289447").checked = false;

    //clear variables incase user wants to run form again
    age = 0;
    moneyAmount = 0;
    goalText = "";
    preferenceText = "";
    internationalText = "";
  }

  $(document).ready(function(){

    $(".flip").click(function(){

        $(this).next(".panel").slideToggle("slow"); //slide next "panel" below "flip"
    });

    //show retirement planning button, hide the other 2 at page load.
    $("#button-wealth").hide();
    $("#button-safety").hide();

    $('a[data-toggle="tab"]').on('shown.bs.tab', function(e){
        var currentTab = $(e.target).text(); // get current tab
        $(".sample").html(currentTab); 

        //show retirement planning button, hide the other 2 at tab click
        if(currentTab == "Retirement Planning"){

          $("#button-retirement").show();
          $("#button-wealth").hide();
          $("#button-safety").hide();
        }

        //show wealth accumulation button, hide the other 2 at tab click
        else if(currentTab == "Wealth Accumulation"){

          $("#button-wealth").show();
          $("#button-retirement").hide();
          $("#button-safety").hide();
        }

        //show safety net button, hide the other 2 at tab click
        else if(currentTab == "Safety Net"){

          $("#button-safety").show();
          $("#button-retirement").hide();
          $("#button-wealth").hide();
        }
    });

  });
