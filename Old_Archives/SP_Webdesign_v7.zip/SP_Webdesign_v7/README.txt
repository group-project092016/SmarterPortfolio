Smarter Portfolio Website V7

Changes:

[x] On smaller screens, changed the dropdown button color on the navbar(header) so it conforms with the rest of the items in the page.

For the PortfolioBuilder.html, ExpectedGrowthCalculator.html, CreditCardWizard.html, and AboutUs.html pages,
[x] Changed the background photo in the jumbotron(container below the header) to avoid copyright issues.
[x] On smaller screens, changed the color of the header to opaque black so that the texts remain readable in case they overlaps with the background photo.

For the index.html page,
[x] Tweaked hover event on tools icons so that they don’t shift down on hover.
[x] Changed the the layer above the background photo to opaque black to make the icons and texts more pronounced.
[x] Changed background photo to avoid copyright issues.

For the PortfolioBuilder.html, ExpectedGrowthCalculator.html, and CreditCardWizard.html pages,
[x] Tweaked the slide toggle speed of the “about this tool” container so that it slides downward and upward much quicker.

For the AboutUs.html page,
[x] Reduced the font size mission and goal statements.
[x] Fixed the alignment of the globe icon on smaller screens.

For the FAQ.html page,
[x] Fixed the script dealing with the sliding panel so that the page does not scroll up everytime a sentence is clicked. 