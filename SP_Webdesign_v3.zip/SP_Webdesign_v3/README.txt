Smarter Portfolio Website V3

Changes:

-Created AboutUs.htm and FAQ.htm.
-Added Leon’s content on to the AboutUs.htm and FAQ.htm.
-Fixed margins on the tools.
-Support, Language, and Privacy Pages removed from the website.
