Smarter Portfolio Website V5

Changes:

-Added background layers to the pages index, about us, and faq.
-Added images to pages portfolio builder, expected growth calculator and credit card wizard.
-Updated credit card wizard using leon’s forms.
-Added description of tools under each title in the tools pages.